    <div class="web-footer" id="webFooter">COPYRIGHT <?php echo date ('Y'); ?>. MADDENBASE | <span class="author-engr">A MaddenBase WordPress Theme is designed by: <a href="https://www.fiverr.com/aslamshah111?up_rollout=true">Eng. Sayed Aslam Shah</a> </span></div>
        
    </div>
  






   
    <?php wp_footer(); ?>
    
  
</body>
</html>